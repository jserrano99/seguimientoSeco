create view view_lineas_seguimiento as
select now()              AS `fecha`,
       `s`.`id`           AS `seguimientoId`,
       `s`.`descripcion`  AS `seguimientoDs`,
       `s`.`fecha_inicio` AS `seguimientoFechaInicio`,
       `s`.`fecha_fin`    AS `seguimientoFechaFin`,
       `a`.`id`           AS `agrupacionId`,
       `a`.`codigo`       AS `agrupacionCd`,
       `a`.`descripcion`  AS `agrupacionDs`,
       `e`.`id`           AS `encargoId`,
       `e`.`numero`       AS `encargoNumero`,
       `e`.`titulo`       AS `encargoTitulo`,
       `oe`.`id`          AS `objetoEncargoId`,
       `oe`.`codigo`      AS `objetoEncargoCd`,
       `oe`.`descripcion` AS `objetoEncargoDs`,
       `ee`.`id`          AS `estadoEncargoId`,
       `ee`.`codigo`      AS `estadoEncargoCd`,
       `ee`.`descripcion` AS `estadoEncargoDs`,
       `ae`.`id`          AS `anotacionId`,
       `ae`.`anotacion`   AS `anotacionDs`,
       `ae`.`fecha`       AS `anotacionFecha`,
       `u`.`id`           AS `usuarioId`,
       `u`.`codigo`       AS `usuarioLogin`,
       `u`.`nombre`       AS `usuarioNombre`
from ((((((`seguimientoseco`.`seguimiento` `s` join `seguimientoseco`.`agrupacion` `a` on ((`a`.`seguimiento_id` = `s`.`id`))) join `seguimientoseco`.`encargo` `e` on ((`e`.`agrupacion_id` = `a`.`id`))) join `seguimientoseco`.`anotaciones_encargo` `ae` on ((`ae`.`encargo_id` = `e`.`id`))) join `seguimientoseco`.`objetos_encargo` `oe` on ((`oe`.`id` = `e`.`objeto_encargo_id`))) join `seguimientoseco`.`estado_encargo` `ee` on ((`ee`.`id` = `e`.`estado_actual_id`)))
         join `seguimientoseco`.`usuario` `u` on ((`u`.`id` = `ae`.`usuario_id`)));

