create view view_actividad_tasada_acum as
select `t1`.`certificado_servicios_id` AS `certificadoServiciosId`,
       `t4`.`codigo`                   AS `agrupacionCd`,
       `t4`.`descripcion`              AS `agrupacionDs`,
       `t3`.`descripcion`              AS `objetoEncargoDs`,
       `t2`.`numero`                   AS `encargoNumero`,
       `t2`.`titulo`                   AS `encargoTitulo`,
       `t4`.`posicion_economica_id`    AS `posicionEconomicaId`,
       `pe`.`descripcion`              AS `posicionEconomicaDs`,
       sum(`t2`.`coste`)               AS `importeAcumulado`
from ((((`seguimientoseco`.`linea_certificado` `t1` join `seguimientoseco`.`encargo` `t2` on ((`t2`.`id` = `t1`.`encargo_id`))) join `seguimientoseco`.`agrupacion` `t4` on ((`t4`.`id` = `t2`.`agrupacion_id`))) join `seguimientoseco`.`objetos_encargo` `t3` on ((`t3`.`id` = `t2`.`objeto_encargo_id`)))
         join `seguimientoseco`.`posicion_economica` `pe` on ((`pe`.`id` = `t4`.`posicion_economica_id`)))
where ((`t1`.`tipo_cuota_id` = 3) and (`t4`.`tipo_agrupacion_id` = 3))
group by `t1`.`certificado_servicios_id`, `t4`.`codigo`;

