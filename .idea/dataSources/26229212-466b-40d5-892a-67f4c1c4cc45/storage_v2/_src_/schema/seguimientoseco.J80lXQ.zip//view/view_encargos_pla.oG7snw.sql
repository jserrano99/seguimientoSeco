create view view_encargos_pla as
select now()                         AS `fecha`,
       `e`.`id`                      AS `encargoId`,
       `e`.`numero`                  AS `encargoNumero`,
       `e`.`fc_estado_actual`        AS `fechaEstadoActual`,
       `e`.`titulo`                  AS `encargoTitulo`,
       `e`.`descripcion`             AS `encardoDs`,
       `e`.`objeto_encargo_id`       AS `objetoEncargoId`,
       `oe`.`codigo`                 AS `objetoEncargoCd`,
       `oe`.`descripcion`            AS `objetoEncargoDs`,
       `t1`.`id`                     AS `tipoObjetoId`,
       `t1`.`descripcion`            AS `tipoObjetoDs`,
       `ee`.`id`                     AS `estadoEncargoId`,
       `ee`.`codigo`                 AS `estadoEncargoCd`,
       `ee`.`descripcion`            AS `estadoEncargoDs`,
       `a`.`id`                      AS `agrupacionId`,
       `a`.`codigo`                  AS `agrupacionCd`,
       `a`.`descripcion`             AS `agrupacionDs`,
       `ta`.`id`                     AS `tipoAgrupacionId`,
       `ta`.`descripcion`            AS `tipoAgrupacionDs`,
       `e`.`fc_comienzo_ejecucion`   AS `fechaComienzoEjecucion`,
       `e`.`fc_compromiso`           AS `fechaCompromiso`,
       `e`.`fc_requerida_entrega`    AS `fechaEntregaRequerida`,
       `e`.`fc_requerida_valoracion` AS `fechaValoracionRequerida`,
       `e`.`fc_entrega_valoracion`   AS `fechaValoracion`,
       `e`.`horas_valoradas`         AS `horasValoradas`,
       `e`.`horas_comprometidas`     AS `horasComprometidas`,
       `e`.`horas_realizadas`        AS `horasRealizadas`,
       `e`.`fc_entrega`              AS `fechaEntrega`,
       `e`.`coste`                   AS `coste`
from (((((`seguimientoseco`.`encargo` `e` join `seguimientoseco`.`objetos_encargo` `oe` on ((`oe`.`id` = `e`.`objeto_encargo_id`))) join `seguimientoseco`.`tipo_objeto` `t1` on ((`t1`.`id` = `oe`.`tipo_objeto_id`))) join `seguimientoseco`.`agrupacion` `a` on ((`a`.`id` = `e`.`agrupacion_id`))) join `seguimientoseco`.`tipo_agrupacion` `ta` on ((`ta`.`id` = `a`.`tipo_agrupacion_id`)))
         join `seguimientoseco`.`estado_encargo` `ee` on ((`ee`.`id` = `e`.`estado_actual_id`)))
where ((`t1`.`id` <> 1) and (`ee`.`id` <> 10));

