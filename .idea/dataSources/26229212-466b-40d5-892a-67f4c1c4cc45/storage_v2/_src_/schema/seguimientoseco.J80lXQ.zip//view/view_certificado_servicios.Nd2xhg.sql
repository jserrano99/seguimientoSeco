create view view_certificado_servicios as
select `seguimientoseco`.`contrato`.`id`                                  AS `contratoId`,
       `seguimientoseco`.`contrato`.`codigo`                              AS `contratoCodigo`,
       `seguimientoseco`.`contrato`.`descripcion`                         AS `contratoDescripcion`,
       `seguimientoseco`.`contrato`.`fc_inicio`                           AS `contratoFechaInicio`,
       `seguimientoseco`.`contrato`.`fc_fin`                              AS `contratoFechaFin`,
       `seguimientoseco`.`contrato`.`centro_coste_cd`                     AS `contratoCentroCosteCd`,
       `seguimientoseco`.`contrato`.`centro_coste_ds`                     AS `contratoCentroCosteDs`,
       `seguimientoseco`.`contrato`.`expediente`                          AS `contratoExpediente`,
       `seguimientoseco`.`contrato`.`adjudicatario`                       AS `contratoAdjudicatario`,
       `seguimientoseco`.`contrato`.`importe_contrato`                    AS `contratoImporteContrato`,
       `seguimientoseco`.`contrato`.`importe_adjudicacion`                AS `contratoImporteAdjudicacion`,
       `seguimientoseco`.`contrato`.`porcentaje_baja`                     AS `contratoPorcentajeBaja`,
       `seguimientoseco`.`contrato`.`numero_pedido`                       AS `contratoNumeroPedido`,
       `seguimientoseco`.`certificado_servicios`.`id`                     AS `certificadoServiciosId`,
       `seguimientoseco`.`certificado_servicios`.`contrato_id`            AS `certificadoServiciosContratoId`,
       `seguimientoseco`.`certificado_servicios`.`descripcion`            AS `certificadoSserviciosDescripcion`,
       `seguimientoseco`.`importes_contrato`.`fc_inicio`                  AS `importesContratoFechaInicio`,
       `seguimientoseco`.`importes_contrato`.`fc_fin`                     AS `importesContratoGechaFin`,
       `seguimientoseco`.`importes_contrato`.`cuota_fija`                 AS `importesContratoCuotaFija`,
       `seguimientoseco`.`importes_contrato`.`cuota_tasada`               AS `importesContratoCuotaTasada`,
       `seguimientoseco`.`importes_contrato`.`tarifa_hora`                AS `importesContratoTarifaHora`,
       `seguimientoseco`.`importes_contrato`.`cuota_fija_mensual`         AS `importesContratoCuotaFijaMensual`,
       `seguimientoseco`.`meses`.`descripcion`                            AS `mesesDescripcion`,
       `seguimientoseco`.`anyos`.`descripcion`                            AS `anyosDescripcion`,
       `seguimientoseco`.`meses`.`descripcion`                            AS `periodo`,
       `seguimientoseco`.`certificado_servicios`.`total_cuota`            AS `totalCuota`,
       `seguimientoseco`.`certificado_servicios`.`base_imponible`         AS `baseImponible`,
       `seguimientoseco`.`certificado_servicios`.`total_penalizaciones`   AS `totalPenalizaciones`,
       `seguimientoseco`.`certificado_servicios`.`maximo_penalizaciones`  AS `maximoPenalizaciones`,
       `seguimientoseco`.`certificado_servicios`.`cuota_iva`              AS `cuotaIva`,
       `seguimientoseco`.`certificado_servicios`.`total_factura_con_iva`  AS `totalFacturaConIva`,
       `seguimientoseco`.`certificado_servicios`.`penalizacion_aplicable` AS `penalizacionAplicable`
from ((((`seguimientoseco`.`certificado_servicios` join `seguimientoseco`.`contrato` on ((
        `seguimientoseco`.`contrato`.`id` =
        `seguimientoseco`.`certificado_servicios`.`contrato_id`))) join `seguimientoseco`.`importes_contrato` on ((
        `seguimientoseco`.`importes_contrato`.`contrato_id` =
        `seguimientoseco`.`contrato`.`id`))) join `seguimientoseco`.`meses` on ((`seguimientoseco`.`meses`.`id` =
                                                                                 `seguimientoseco`.`certificado_servicios`.`meses_id`)))
         join `seguimientoseco`.`anyos` on ((`seguimientoseco`.`anyos`.`id` = `seguimientoseco`.`meses`.`anyo_id`)));

