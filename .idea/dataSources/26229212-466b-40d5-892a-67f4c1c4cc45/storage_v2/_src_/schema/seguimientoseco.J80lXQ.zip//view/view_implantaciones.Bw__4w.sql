create view view_implantaciones as
select `e`.`id`                AS `encargoId`,
       `e`.`numero`            AS `numeroEncargo`,
       `e`.`fc_estado_actual`  AS `fechaEstadoActual`,
       `e`.`titulo`            AS `encargoTitulo`,
       `e`.`objeto_encargo_id` AS `objetoEncargoId`,
       `oe`.`codigo`           AS `objetoEncargoCd`,
       `oe`.`descripcion`      AS `objetoEncargoDs`,
       `ee`.`id`               AS `estadoEncargoId`,
       `ee`.`codigo`           AS `estadoEncargoCd`,
       `ee`.`descripcion`      AS `estadoEncargoDs`,
       `a`.`id`                AS `agrupacionId`,
       `a`.`codigo`            AS `agrupacionCd`,
       `a`.`descripcion`       AS `agrupacionDs`,
       `ta`.`id`               AS `tipoAgrupacionId`,
       `ta`.`descripcion`      AS `tipoAgrupacionDs`
from (((((`seguimientoseco`.`encargo` `e` join `seguimientoseco`.`objetos_encargo` `oe` on ((`oe`.`id` = `e`.`objeto_encargo_id`))) join `seguimientoseco`.`tipo_objeto` `t1` on ((`t1`.`id` = `oe`.`tipo_objeto_id`))) join `seguimientoseco`.`agrupacion` `a` on ((`a`.`id` = `e`.`agrupacion_id`))) join `seguimientoseco`.`tipo_agrupacion` `ta` on ((`ta`.`id` = `a`.`tipo_agrupacion_id`)))
         join `seguimientoseco`.`estado_encargo` `ee` on ((`ee`.`id` = `e`.`estado_actual_id`)))
where ((`t1`.`id` = 2) and (`ta`.`id` = 3));

