create view view_adaptaciones_menores as
select `t1`.`id`                       AS `lineaCertificadoId`,
       `t1`.`certificado_servicios_id` AS `certificadoServiciosId`,
       `t2`.`id`                       AS `encargoId`,
       `t2`.`numero`                   AS `encargoNumero`,
       `t2`.`titulo`                   AS `encargoTitulo`,
       `t2`.`horas_realizadas`         AS `horasRealizadas`,
       `t3`.`id`                       AS `objeetoEncargoId`,
       `t3`.`codigo`                   AS `objetoEncargoCd`,
       `t3`.`descripcion`              AS `objetoEncargoDs`,
       `t4`.`id`                       AS `agrupacionId`,
       `t4`.`codigo`                   AS `agrupacionCd`,
       `t4`.`descripcion`              AS `agrupacionDs`
from (((`seguimientoseco`.`linea_certificado` `t1` join `seguimientoseco`.`encargo` `t2` on ((`t2`.`id` = `t1`.`encargo_id`))) join `seguimientoseco`.`agrupacion` `t4` on ((`t4`.`id` = `t2`.`agrupacion_id`)))
         join `seguimientoseco`.`objetos_encargo` `t3` on ((`t3`.`id` = `t2`.`objeto_encargo_id`)))
where (`t3`.`tipo_objeto_id` = 3);

