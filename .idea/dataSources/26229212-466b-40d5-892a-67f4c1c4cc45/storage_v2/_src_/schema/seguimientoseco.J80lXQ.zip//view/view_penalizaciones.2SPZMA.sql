create view view_penalizaciones as
select `cs`.`id`                        AS `certificadoServiciosId`,
       `i`.`id`                         AS `indicadorId`,
       `i`.`codigo`                     AS `indicadorCd`,
       `i`.`descripcion`                AS `indicadorDs`,
       `p`.`total_encargos_penalizados` AS `encargosPenalizados`,
       `p`.`total_encargos`             AS `totalEncargos`,
       `p`.`total_cumplen`              AS `totalCumplen`,
       `p`.`porcentaje`                 AS `porcentaje`,
       `p`.`importe`                    AS `importe`,
       `m`.`descripcion`                AS `periodo`,
       `c`.`descripcion`                AS `contratoDs`
from ((((`seguimientoseco`.`penalizaciones` `p` join `seguimientoseco`.`indicadores` `i` on ((`i`.`id` = `p`.`indicador_id`))) join `seguimientoseco`.`certificado_servicios` `cs` on ((`cs`.`id` = `p`.`certificado_servicios_id`))) join `seguimientoseco`.`meses` `m` on ((`m`.`id` = `cs`.`meses_id`)))
         join `seguimientoseco`.`contrato` `c` on ((`c`.`id` = `cs`.`contrato_id`)));

