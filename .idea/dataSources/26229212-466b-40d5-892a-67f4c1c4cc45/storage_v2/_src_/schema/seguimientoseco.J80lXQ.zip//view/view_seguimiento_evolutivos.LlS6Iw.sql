create view view_seguimiento_evolutivos as
select now()                          AS `fecha`,
       `t1`.`codigo`                  AS `agrupacionCd`,
       `t1`.`descripcion`             AS `agrupacionDs`,
       `t2`.`numero`                  AS `numeroEncargo`,
       `t2`.`titulo`                  AS `tituloEncargo`,
       `t2`.`nm_remedy`               AS `nmRemedy`,
       `t3`.`codigo`                  AS `objetoEncargoCd`,
       `t3`.`descripcion`             AS `objetoEncargoDs`,
       `t4`.`codigo`                  AS `estadoEncargoCd`,
       `t4`.`descripcion`             AS `estadoEncargoDs`,
       `t2`.`fc_estado_actual`        AS `fcEstadoActual`,
       `t2`.`fc_requerida_valoracion` AS `fcRequeridaValoracion`,
       `t2`.`fc_entrega_valoracion`   AS `fcEntregaValoracion`,
       `t2`.`fc_requerida_entrega`    AS `fcRequeridaEntrega`,
       `t2`.`fc_compromiso`           AS `fcCompromisoEntrega`,
       `t2`.`fc_entrega`              AS `fcEntrega`,
       `t2`.`horas_comprometidas`     AS `horasComprometidas`,
       `t2`.`horas_realizadas`        AS `horasRealizadas`
from (((`seguimientoseco`.`agrupacion` `t1` join `seguimientoseco`.`encargo` `t2` on ((`t2`.`agrupacion_id` = `t1`.`id`))) join `seguimientoseco`.`objetos_encargo` `t3` on ((`t3`.`id` = `t2`.`objeto_encargo_id`)))
         join `seguimientoseco`.`estado_encargo` `t4` on ((`t4`.`id` = `t2`.`estado_actual_id`)))
where ((`t1`.`tipo_agrupacion_id` = 1) and (`t3`.`tipo_objeto_id` = 2));

