create view view_seguimiento_servicio_cf as
select `vlc`.`criticidadDs`                                           AS `criticidadDs`,
       `vlc`.`tipoCuotaId`                                            AS `tipoCuotaId`,
       `vlc`.`tipoCuotaDs`                                            AS `tipoCuotaDs`,
       `vlc`.`tipoObjetoId`                                           AS `tipoObjetoId`,
       `vlc`.`tipoObjetoDs`                                           AS `tipoObjetoDs`,
       `vlc`.`objetoEncargoId`                                        AS `objetoEncargoId`,
       `vlc`.`objetoEncargoDs`                                        AS `objetoEncargoDs`,
       `vlc`.`periodoId`                                              AS `periodoId`,
       `vlc`.`periodo`                                                AS `periodo`,
       count(`vlc`.`encargoNumero`)                                   AS `totalEncargos`,
       sum(`vlc`.`horasRealidas`)                                     AS `horasRealizadas`,
       sum(`vlc`.`horasComprometidas`)                                AS `horasComprometidas`,
       sum(`vlc`.`tiempoResolucion`)                                  AS `tiempoResolucion`,
       (sum(`vlc`.`tiempoResolucion`) / count(`vlc`.`encargoNumero`)) AS `tiempoMedioResolucion`
from `seguimientoseco`.`view_lineas_certificado` `vlc`
where (`vlc`.`tipoCuotaId` = 1)
group by `vlc`.`criticidadId`, `vlc`.`objetoEncargoCd`, `vlc`.`objetoEncargoDs`, `vlc`.`periodo`
order by `vlc`.`objetoEncargoDs`, `vlc`.`periodoId`;

