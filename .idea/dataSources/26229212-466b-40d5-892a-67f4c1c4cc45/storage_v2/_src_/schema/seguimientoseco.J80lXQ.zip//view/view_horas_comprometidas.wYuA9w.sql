create view view_horas_comprometidas as
select now()                       AS `fecha`,
       `e`.`id`                    AS `encargoId`,
       `e`.`numero`                AS `encargoNumero`,
       `e`.`titulo`                AS `encargoTitulo`,
       `e`.`estado_actual_id`      AS `estadoEncargoId`,
       `ee`.`codigo`               AS `estadoEncargoCd`,
       `ee`.`descripcion`          AS `estadoEncargoDs`,
       `e`.`objeto_encargo_id`     AS `objetoEncargoId`,
       `oe`.`codigo`               AS `objetoEncargoCd`,
       `oe`.`descripcion`          AS `objetoEncargoDs`,
       `ay`.`id`                   AS `anualidadId`,
       `ay`.`descripcion`          AS `anualidadDs`,
       `m`.`id`                    AS `periodoId`,
       `m`.`descripcion`           AS `periodoDs`,
       `m`.`fecha_inicio`          AS `fechaInicioPeriodo`,
       `e`.`fc_compromiso`         AS `fechaCompromiso`,
       `a`.`id`                    AS `agrupacionId`,
       `a`.`codigo`                AS `agrupacionCd`,
       `a`.`descripcion`           AS `agrupacionDs`,
       `e`.`coste`                 AS `encargoCoste`,
       `e`.`horas_comprometidas`   AS `horasComprometidas`,
       `a`.`tipo_agrupacion_id`    AS `tipoAgrupacion`,
       `e`.`fc_comienzo_ejecucion` AS `fechaComienzoEjecucion`,
       `pe`.`id`                   AS `posicionEconomicaId`,
       `pe`.`descripcion`          AS `posicionEconomicaDs`
from ((((((`seguimientoseco`.`encargo` `e` join `seguimientoseco`.`meses` `m` on ((`e`.`fc_compromiso` between `m`.`fecha_inicio` and `m`.`fecha_fin`))) join `seguimientoseco`.`anyos` `ay` on ((`ay`.`id` = `m`.`anyo_id`))) join `seguimientoseco`.`objetos_encargo` `oe` on ((`oe`.`id` = `e`.`objeto_encargo_id`))) join `seguimientoseco`.`estado_encargo` `ee` on ((`ee`.`id` = `e`.`estado_actual_id`))) join `seguimientoseco`.`agrupacion` `a` on ((`a`.`id` = `e`.`agrupacion_id`)))
         join `seguimientoseco`.`posicion_economica` `pe` on ((`pe`.`id` = `a`.`posicion_economica_id`)))
where ((`oe`.`tipo_objeto_id` = 2) and (`ee`.`codigo` in ('EJE', 'PVE')) and (`a`.`tipo_agrupacion_id` in (1, 3)));

