create view view_encargos_cf as select `v1`.`certificadoServiciosId` AS `certificadoServiciosId`,
                                       `v1`.`encargoId`              AS `encargoId`,
                                       `v1`.`nmEncargo`              AS `nmEncargo`,
                                       `v1`.`encargoTitulo`          AS `encargoTitulo`,
                                       `v1`.`estadoCd`               AS `estadoCd`,
                                       `v1`.`estadoDs`               AS `estadoDs`,
                                       `v1`.`objetoEncargoCd`        AS `objetoEncargoCd`,
                                       `v1`.`objetoEncargoDs`        AS `objetoEncargoDs`,
                                       `v1`.`fechaComienzoEjecucion` AS `fechaComienzoEjecucion`,
                                       `v1`.`fechaCompromiso`        AS `fechaCompromiso`,
                                       `v1`.`horasComprometidas`     AS `horasComprometidas`,
                                       `v1`.`diasTotales`            AS `diasTotales`,
                                       `v1`.`diasMes`                AS `diasMes`,
                                       `v1`.`HorasDia`               AS `horasDia`,
                                       `v1`.`horasMes`               AS `horasMes`
                                from `seguimientoseco`.`view_encargos_cf_cerrados` `v1`
                                where (`v1`.`tipoObjetoCd` = 'SCF')
                                union
                                select `v1`.`certificadoServiciosId` AS `certificadoServiciosId`,
                                       `v1`.`encargoId`              AS `encargoId`,
                                       `v1`.`nmEncargo`              AS `nmEncargo`,
                                       `v1`.`encargoTitulo`          AS `encargoTitulo`,
                                       `v1`.`estadoCd`               AS `estadoCd`,
                                       `v1`.`estadoDs`               AS `estadoDs`,
                                       `v1`.`objetoEncargoCd`        AS `objetoEncargoCd`,
                                       `v1`.`objetoEncargoDs`        AS `objetoEncargoDs`,
                                       `v1`.`fechaComienzoEjecucion` AS `fechaComienzoEjecucion`,
                                       `v1`.`fechaCompromiso`        AS `fechaCompromiso`,
                                       `v1`.`horasComprometidas`     AS `horasComprometidas`,
                                       `v1`.`diasTotales`            AS `diasTotales`,
                                       `v1`.`diasMes`                AS `diasMes`,
                                       `v1`.`horasDia`               AS `horasDia`,
                                       `v1`.`horasMes`               AS `horasMes`
                                from `seguimientoseco`.`view_encargos_cf_en_ejecucion` `v1`;

