create view view_importes_acumulado as
select `a`.`id`                       AS `anualidadId`,
       `a`.`descripcion`              AS `anualidadDs`,
       `ics`.`descripcion`            AS `importeDescripcion`,
       `pe`.`id`                      AS `posicionEconomicaId`,
       `pe`.`descripcion`             AS `posicionEconomicaDs`,
       round(sum(`ics`.`importe`), 2) AS `importe`
from ((((`seguimientoseco`.`certificado_servicios` `cs` join `seguimientoseco`.`meses` `m` on ((`m`.`id` = `cs`.`meses_id`))) join `seguimientoseco`.`anyos` `a` on ((`a`.`id` = `m`.`anyo_id`))) join `seguimientoseco`.`importes_certificado_servicios` `ics` on ((`ics`.`certificado_servicios_id` = `cs`.`id`)))
         join `seguimientoseco`.`posicion_economica` `pe` on ((`pe`.`id` = `ics`.`posicion_economica_id`)))
group by `a`.`id`, `ics`.`descripcion`;

