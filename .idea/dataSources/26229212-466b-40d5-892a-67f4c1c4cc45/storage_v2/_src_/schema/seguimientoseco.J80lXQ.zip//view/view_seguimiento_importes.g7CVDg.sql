create view view_seguimiento_importes as
select `va`.`anualidadId`         AS `anualidadId`,
       `va`.`anualidad`           AS `anualidad`,
       `va`.`posicionEconomicaDs` AS `posicionEconomicaDs`,
       `va`.`importeAnualidad`    AS `importeAnualidad`,
       `via`.`importe`            AS `importe`
from (`seguimientoseco`.`view_anualidades` `va`
         left join `seguimientoseco`.`view_importes_acumulado` `via`
                   on (((`via`.`posicionEconomicaId` = `va`.`posicionEconomicaId`) and
                        (`via`.`anualidadId` = `va`.`anualidadId`))));

