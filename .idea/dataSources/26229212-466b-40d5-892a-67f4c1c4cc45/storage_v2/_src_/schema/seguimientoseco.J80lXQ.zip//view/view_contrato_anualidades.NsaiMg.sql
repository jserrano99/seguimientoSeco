create view view_contrato_anualidades as
select `c`.`id`                   AS `contratoId`,
       `c`.`codigo`               AS `contratoCd`,
       `c`.`descripcion`          AS `contratoDs`,
       `c`.`fc_inicio`            AS `contratoFechaInicio`,
       `c`.`fc_fin`               AS `contratoFechaFin`,
       `c`.`expediente`           AS `contratoExpediente`,
       `c`.`importe_contrato`     AS `importeContrato`,
       `c`.`importe_adjudicacion` AS `importeAdjudicacion`,
       `ay`.`id`                  AS `anualidadId`,
       `ay`.`descripcion`         AS `anualidadDs`
from ((`seguimientoseco`.`contrato` `c` join `seguimientoseco`.`meses` `m` on ((`m`.`fecha_inicio` between `c`.`fc_inicio` and `c`.`fc_fin`)))
         join `seguimientoseco`.`anyos` `ay` on ((`ay`.`id` = `m`.`anyo_id`)))
group by `ay`.`id`;

