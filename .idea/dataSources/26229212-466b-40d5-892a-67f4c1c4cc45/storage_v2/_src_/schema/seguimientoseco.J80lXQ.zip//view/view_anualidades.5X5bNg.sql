create view view_anualidades as
select `c`.`id`           AS `contratoId`,
       `c`.`descripcion`  AS `contratoDs`,
       `a`.`id`           AS `anualidadId`,
       `a`.`descripcion`  AS `anualidad`,
       `pe`.`id`          AS `posicionEconomicaId`,
       `pe`.`descripcion` AS `posicionEconomicaDs`,
       `ica`.`importe`    AS `importeAnualidad`
from (((`seguimientoseco`.`contrato` `c` join `seguimientoseco`.`importes_contrato_anualidad` `ica` on ((`ica`.`contrato_id` = `c`.`id`))) join `seguimientoseco`.`anyos` `a` on ((`a`.`id` = `ica`.`anyo_id`)))
         join `seguimientoseco`.`posicion_economica` `pe` on ((`pe`.`id` = `ica`.`posicion_economica_id`)));

