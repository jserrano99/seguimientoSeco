create view view_encargos_penalizados as
select `c`.`descripcion`              AS `contratoDs`,
       `cs`.`id`                      AS `certificadoServiciosId`,
       `m`.`id`                       AS `mesId`,
       `m`.`descripcion`              AS `periodo`,
       `i`.`id`                       AS `indicadorId`,
       `i`.`codigo`                   AS `indicadorCd`,
       `i`.`descripcion`              AS `indicadorDs`,
       `e`.`id`                       AS `encargoId`,
       `e`.`numero`                   AS `encargoNumero`,
       `e`.`titulo`                   AS `encargoTitulo`,
       `e`.`nm_remedy`                AS `numeroRemedy`,
       `ep`.`id`                      AS `encargoPenalizadoId`,
       `ep`.`eliminada`               AS `eliminada`,
       `ep`.`dias_retraso_entrega`    AS `diasRetrasoEntrega`,
       `ep`.`dias_retraso_valoracion` AS `diasRetrasoValoracion`,
       `ep`.`dias_ejecucion`          AS `diasEjecucion`,
       `e`.`fc_comienzo_ejecucion`    AS `fcComienzoEjecucion`,
       `e`.`fc_entrega_valoracion`    AS `fcEntregaValoracion`,
       `e`.`fc_requerida_valoracion`  AS `fcRequeridaValoracion`,
       `e`.`fc_compromiso`            AS `fcCompromiso`,
       `e`.`fc_entrega`               AS `fecEntrega`,
       `e`.`coste`                    AS `costeEncargo`
from (((((`seguimientoseco`.`certificado_servicios` `cs` join `seguimientoseco`.`encargo_penalizado` `ep` on ((`ep`.`certificado_servicios_id` = `cs`.`id`))) join `seguimientoseco`.`encargo` `e` on ((`e`.`id` = `ep`.`encargo_id`))) join `seguimientoseco`.`indicadores` `i` on ((`i`.`id` = `ep`.`indicador_id`))) join `seguimientoseco`.`meses` `m` on ((`m`.`id` = `cs`.`meses_id`)))
         join `seguimientoseco`.`contrato` `c` on ((`c`.`id` = `cs`.`contrato_id`)));

